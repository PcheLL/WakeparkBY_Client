package com.wakeparkby.Client;

        import lombok.Getter;


public class Const {
    static final String TIMESPACE_URL = "http://52.59.235.201:8080";
}
